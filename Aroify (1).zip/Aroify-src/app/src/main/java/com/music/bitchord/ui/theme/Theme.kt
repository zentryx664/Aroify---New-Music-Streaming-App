package com.music.bitchord.ui.theme

import android.app.Activity
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Easing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import com.music.bitchord.R

// Deep rose, kept under its old name for the spots (Replay's rank badge) that
// want a fixed warm accent regardless of theme.
val AccentRed = Color(0xFFE0307F)

// "Aurora" palette: electric violet as the lead accent, with mint and rose as
// supporting colours. Black is deliberately left alone: the dark theme keeps a
// true-black background (OLED-friendly) and only the colours *on* it change.
val AuroraViolet = Color(0xFFB69CFF)
val AuroraViolet500 = Color(0xFF6B3FE0)
val AuroraMint = Color(0xFF5EEAD4)
val AuroraRose = Color(0xFFFF7AB6)
val AuroraSky = Color(0xFF7CC4FF)

/** The signature accent sweep, for highlights, progress and hero surfaces. */
val AuroraGradient: Brush = Brush.linearGradient(listOf(AuroraViolet, AuroraRose, AuroraMint))

private val DarkColors = darkColorScheme(
    primary = AuroraViolet,
    onPrimary = Color(0xFF1A0B3D),
    primaryContainer = Color(0xFF3B2A7A),
    onPrimaryContainer = Color(0xFFE6DEFF),
    secondary = AuroraMint,
    onSecondary = Color(0xFF00382F),
    secondaryContainer = Color(0xFF0F4A41),
    onSecondaryContainer = Color(0xFFB4F5EA),
    tertiary = AuroraRose,
    onTertiary = Color(0xFF4A0B2B),
    tertiaryContainer = Color(0xFF6B1F44),
    onTertiaryContainer = Color(0xFFFFD8EA),
    background = Color.Black,
    onBackground = Color(0xFFF4F0FF),
    surface = Color(0xFF0E0B16),
    onSurface = Color(0xFFF4F0FF),
    surfaceVariant = Color(0xFF1B1530),
    onSurfaceVariant = Color(0xFFA79CC4),
    outline = Color(0xFF2E2547),
    outlineVariant = Color(0xFF241D3A),
    error = Color(0xFFFF6B7A),
)

private val LightColors = lightColorScheme(
    primary = AuroraViolet500,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE6DEFF),
    onPrimaryContainer = Color(0xFF22095F),
    secondary = Color(0xFF00897B),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFB4F5EA),
    onSecondaryContainer = Color(0xFF00201B),
    tertiary = Color(0xFFD6307F),
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFD8EA),
    onTertiaryContainer = Color(0xFF3E001F),
    background = Color(0xFFFBF9FF),
    onBackground = Color(0xFF16122A),
    surface = Color(0xFFF4F0FF),
    onSurface = Color(0xFF16122A),
    surfaceVariant = Color(0xFFEAE4FA),
    onSurfaceVariant = Color(0xFF665D82),
    outline = Color(0xFFD9D0F0),
    outlineVariant = Color(0xFFE6DFF7),
    error = Color(0xFFD93A4C),
)

/**
 * One motion language for the whole app. Everything that moves between pages
 * or reveals itself draws its timing from here, so the app feels like a single
 * piece rather than a set of unrelated animations.
 */
object AppMotion {
    /** Gentle ease-out: quick to start, long soft landing. */
    val Emphasized: Easing = CubicBezierEasing(0.2f, 0f, 0f, 1f)

    /** Used when something leaves: accelerates away. */
    val EmphasizedAccelerate: Easing = CubicBezierEasing(0.3f, 0f, 0.8f, 0.15f)

    const val PageEnterMs = 380
    const val PageExitMs = 220
    const val FadeMs = 260

    /** Fraction of the width a pushed page travels: small, so it reads as depth rather than a wipe. */
    const val PageSlideFraction = 10

    /** Soft, non-bouncy spring for small state changes (selection, press, size). */
    fun <T> softSpring() = spring<T>(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow)
}

/**
 * SF Pro Display, the face Apple Music itself is set in. Only the weights the
 * type scale actually asks for are bundled; Compose synthesises nothing, so a
 * missing weight would silently fall back to the nearest one shipped.
 */
val SFProDisplay = FontFamily(
    Font(R.font.sf_pro_display_regular, FontWeight.W400),
    Font(R.font.sf_pro_display_medium, FontWeight.W500),
    Font(R.font.sf_pro_display_semibold, FontWeight.W600),
    Font(R.font.sf_pro_display_bold, FontWeight.W700),
    Font(R.font.sf_pro_display_heavy, FontWeight.W800),
)

// Heavy, tight typography — the backbone of the Apple Music look.
private val BitChordTypography = Typography(
    displayLarge = TextStyle(fontWeight = FontWeight.W800, fontSize = 34.sp, letterSpacing = (-0.8).sp),
    headlineLarge = TextStyle(fontWeight = FontWeight.W800, fontSize = 30.sp, letterSpacing = (-0.7).sp),
    headlineMedium = TextStyle(fontWeight = FontWeight.W700, fontSize = 22.sp, letterSpacing = (-0.4).sp),
    titleLarge = TextStyle(fontWeight = FontWeight.W700, fontSize = 20.sp, letterSpacing = (-0.3).sp),
    titleMedium = TextStyle(fontWeight = FontWeight.W600, fontSize = 16.sp, letterSpacing = (-0.2).sp),
    bodyLarge = TextStyle(fontWeight = FontWeight.W400, fontSize = 16.sp),
    bodyMedium = TextStyle(fontWeight = FontWeight.W400, fontSize = 14.sp),
    labelMedium = TextStyle(fontWeight = FontWeight.W600, fontSize = 12.sp),
    labelSmall = TextStyle(fontWeight = FontWeight.W600, fontSize = 11.sp),
).withFamily(SFProDisplay)

/** Applies [family] to every style in the scale, so nothing is left on Roboto. */
private fun Typography.withFamily(family: FontFamily) = Typography(
    displayLarge = displayLarge.copy(fontFamily = family),
    displayMedium = displayMedium.copy(fontFamily = family),
    displaySmall = displaySmall.copy(fontFamily = family),
    headlineLarge = headlineLarge.copy(fontFamily = family),
    headlineMedium = headlineMedium.copy(fontFamily = family),
    headlineSmall = headlineSmall.copy(fontFamily = family),
    titleLarge = titleLarge.copy(fontFamily = family),
    titleMedium = titleMedium.copy(fontFamily = family),
    titleSmall = titleSmall.copy(fontFamily = family),
    bodyLarge = bodyLarge.copy(fontFamily = family),
    bodyMedium = bodyMedium.copy(fontFamily = family),
    bodySmall = bodySmall.copy(fontFamily = family),
    labelLarge = labelLarge.copy(fontFamily = family),
    labelMedium = labelMedium.copy(fontFamily = family),
    labelSmall = labelSmall.copy(fontFamily = family),
)

@Composable
fun BitChordTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = BitChordTypography,
        content = content,
    )
}

/**
 * Draws the status and navigation bar glyphs dark or light.
 *
 * `enableEdgeToEdge()` decides this from the *system* dark-mode setting, which
 * is the wrong input the moment the in-app theme disagrees with it: Light theme
 * on a phone in dark mode left white icons on a white bar, invisible. The bars
 * have to follow the content the app is actually painting. The player supplies
 * its own stable light-icon value and paints contrast behind it; every other
 * surface follows the theme. Hence a parameter rather than reading it here.
 */
@Composable
fun SystemBarIcons(dark: Boolean) {
    val view = LocalView.current
    if (view.isInEditMode) return
    val window = findWindow(view) ?: return
    SideEffect {
        WindowCompat.getInsetsController(window, view).apply {
            isAppearanceLightStatusBars = dark
            isAppearanceLightNavigationBars = dark
        }
    }
}

